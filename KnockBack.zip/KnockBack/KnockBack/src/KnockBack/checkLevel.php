<?php

namespace KnockBack;

use pocketmine\scheduler\PluginTask;

class checkLevel extends PluginTask {
	
	public function __construct(KnockBack $plugin){
		parent::__construct($plugin);
		$this->plugin = $plugin;
	}
	
	public function onRun($currentTick){
		$this->plugin->checkLevelTask();
	}
}